from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
    gpa_result = ""
    if request.method == 'POST':
        try:
            total_hours = float(request.form.get('hours'))
            current_gpa = float(request.form.get('current_gpa'))
            new_course_hours = float(request.form.get('new_course_hours'))
            new_course_grade = float(request.form.get('new_course_grade'))

            # حساب GPA الجديد
            total_points = current_gpa * total_hours + new_course_grade * new_course_hours
            total_hours += new_course_hours
            new_gpa = total_points / total_hours
            gpa_result = f"الـ GPA الجديد: {new_gpa:.2f}"
        except:
            gpa_result = "ادخل بيانات صحيحة"
    return render_template('index.html', gpa_result=gpa_result)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
